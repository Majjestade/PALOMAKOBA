package com.example.pagamentodecompras;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
   //atributos
    private CheckBox ck_arroz,ck_carne,ck_pao,ck_leite,ck_ovos;
    private Button btn_total,btn_pagamento;
    private RadioGroup rd_group;
    private RadioButton rb_desconto,rb_5,rb_10,rb_15;
    private TextView txt_total;
    private EditText edt_pago;
    Double total=0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //linkagem
        ck_arroz = findViewById(R.id.ck_arroz);
        ck_carne = findViewById(R.id.ck_carne);
        ck_pao = findViewById(R.id.ck_pao);
        ck_leite = findViewById(R.id.ck_leite);
        ck_ovos = findViewById(R.id.ck_ovos);
        btn_total = findViewById(R.id.btn_total);
        btn_pagamento = findViewById(R.id.btn_pagar);
        rd_group = findViewById(R.id.rd_group);
        rb_desconto = findViewById(R.id.rb_desconto);
        rb_5 = findViewById(R.id.rb_5);
        rb_10 = findViewById(R.id.rb_10);
        rb_15 = findViewById(R.id.rb_15);
        txt_total = findViewById(R.id.txt_total);
        edt_pago = findViewById(R.id.edt_pago);

        //acao do botao total
        btn_total.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if(ck_arroz.isChecked()){
                    total+=3.50;
                }
                if(ck_carne.isChecked()){
                    total+=12.30;
                }
                if(ck_pao.isChecked()){
                    total+=2.20;
                }
                if(ck_leite.isChecked()){
                    total+=5.50;
                }
                if(ck_ovos.isChecked()){
                    total+=7.50;
                }
                txt_total.setText("Valor: "+total);
            }
        });

        //acao do botao pagamento
        btn_pagamento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int op = rd_group.getCheckedRadioButtonId();
                String desconto = "";
                double troco = 0.0;
                String pago = edt_pago.getText().toString();

                if (!pago.isEmpty()) {
                    if (op == R.id.rb_desconto) {
                        desconto = "0%";
                        double valor = Double.parseDouble(pago);
                        troco = valor - total;
                        if(valor>total) {
                            AlertDialog.Builder janela = new AlertDialog.Builder(MainActivity.this);
                            janela.setTitle(R.string.app_name);
                            janela.setMessage(String.format("Total da compra: %.2f\n Desconto: %s\n valor pago: %.2f\n Troco: %.2f", total, desconto, valor, troco));
                            janela.setNeutralButton("OK", null);
                            janela.show();
                        }
                        else{
                            Toast.makeText(MainActivity.this,"Valor incompativel com a compra",Toast.LENGTH_SHORT).show();
                        }
                    }

                    if(op == R.id.rb_5){
                        double valor = Double.parseDouble(edt_pago.getText().toString());
                        desconto = "5%";
                        troco = valor - (total-(total*0.05));
                        if(valor>total) {
                            AlertDialog.Builder janela = new AlertDialog.Builder(MainActivity.this);
                            janela.setTitle(R.string.app_name);
                            janela.setMessage(String.format("Total da compra: %.2f\n Desconto: %s\n valor pago: %.2f\n Troco: %.2f", total, desconto, valor, troco));
                            janela.setNeutralButton("OK", null);
                            janela.show();
                        }
                        else{
                            Toast.makeText(MainActivity.this,"Valor incompativel com a compra",Toast.LENGTH_SHORT).show();
                        }

                    }
                    if(op == R.id.rb_10){
                        double valor = Double.parseDouble(edt_pago.getText().toString());
                        desconto = "10%";
                        troco = valor - (total-(total*0.10));
                        if(valor>total) {
                            AlertDialog.Builder janela = new AlertDialog.Builder(MainActivity.this);
                            janela.setTitle(R.string.app_name);
                            janela.setMessage(String.format("Total da compra: %.2f\n Desconto: %s\n valor pago: %.2f\n Troco: %.2f", total, desconto, valor, troco));
                            janela.setNeutralButton("OK", null);
                            janela.show();
                        }
                        else{
                            Toast.makeText(MainActivity.this,"Valor incompativel com a compra",Toast.LENGTH_SHORT).show();
                        }
                    }
                    if(op == R.id.rb_15){
                        double valor = Double.parseDouble(edt_pago.getText().toString());
                        desconto = "15%";
                        troco = valor - (total-(total*0.15));
                        if(valor>total) {
                            AlertDialog.Builder janela = new AlertDialog.Builder(MainActivity.this);
                            janela.setTitle(R.string.app_name);
                            janela.setMessage(String.format("Total da compra: %.2f\n Desconto: %s\n valor pago: %.2f\n Troco: %.2f", total, desconto, valor, troco));
                            janela.setNeutralButton("OK", null);
                            janela.show();
                        }
                        else{
                            Toast.makeText(MainActivity.this,"Valor incompativel com a compra",Toast.LENGTH_SHORT).show();
                        }
                    }

                } else{
                    Toast.makeText(MainActivity.this,"Valor incompativel com a compra",Toast.LENGTH_SHORT).show();
                } //end else
            } //end onclick
        }); //end setOnclicklistener
    } //end oncreate
}//end classe