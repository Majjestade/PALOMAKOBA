package com.example.projetofinalandroid2;


import androidx.appcompat.app.AppCompatActivity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.BatteryManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.projetofinalandroid2.api.CEPService;
import com.example.projetofinalandroid2.model.CEP;
import com.example.projetofinalandroid2.model.Endereco;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Tela_CEP extends AppCompatActivity implements SensorEventListener {

    private Button botaoRecuperar;
    private Button btn_salvar;
    private Button btn_lista;
    private Button btn_mapa;
    private TextView textoResultado;
    private EditText edtCEP;
    private Retrofit retrofit;
    private Endereco ender;
    private String numero_cep;
    private SensorManager sensorManager;
    private Sensor acelerometro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_cep);
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        acelerometro = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        //linkagem
        botaoRecuperar = findViewById(R.id.btnRecuperar);
        textoResultado = findViewById(R.id.txtExibir);
        edtCEP = findViewById(R.id.edtCEP);
        btn_salvar = findViewById(R.id.btn_salvar);
        btn_lista = findViewById(R.id.btn_lista);
        btn_mapa = findViewById(R.id.btn_mapa);


        String urlCep = "https://viacep.com.br/ws/";
        retrofit =  new Retrofit.Builder()
                .baseUrl(urlCep)
                .addConverterFactory(GsonConverterFactory.create())
                .build();


        botaoRecuperar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                recuperarCep();
            }
        });

        btn_salvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                ContentValues cv = new ContentValues();
                cv.put("cep", numero_cep);
                cv.put("rua", ender.getRua());
                cv.put("bairro", ender.getBairro());
                cv.put("cidade", ender.getCidade());

                BancoDeEnderecos bd = new BancoDeEnderecos(Tela_CEP.this);

                String msg = "";
                long res = bd.inserir(cv);

                if(res > 0){
                    msg = "Endereço salvo com sucesso.";


                }
                else{
                    msg = "Ocorreu um erro durante o armazenamento do endereço";
                }
                Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
            }
        });

       btn_lista.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Intent i2 = new Intent(Tela_CEP.this,Tela_enderecos.class);
               startActivity(i2);
           }
       });

       btn_mapa.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent i3 = new Intent(Tela_CEP.this,Mapa.class);
               startActivity(i3);
           }
       });

    }

    public void recuperarCep(){
        CEPService cepService = retrofit.create(CEPService.class);
        numero_cep = edtCEP.getText().toString();
        Call<CEP> call = cepService.recuperarCEP(numero_cep);
        call.enqueue(new Callback<CEP>() {
            @Override
            public void onResponse(Call<CEP> call, Response<CEP> response) {
                if(response.isSuccessful()){
                    CEP cep = response.body();
                    textoResultado.
                            setText(cep.getLogradouro()+"/"+cep.getBairro()+"/"+cep.getLocalidade());
                    ender = new Endereco(cep.getLogradouro(),cep.getBairro(),cep.getLocalidade());

                }
            }

            @Override
            public void onFailure(Call<CEP> call, Throwable t) {

            }
        });
    }
        @Override
        protected void onResume() {
            super.onResume();
            sensorManager.registerListener(Tela_CEP.this, acelerometro, SensorManager.SENSOR_DELAY_NORMAL);
            this.registerReceiver(medeBateria, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        }
        @Override
        protected void onPause() {
            super.onPause();
            sensorManager.unregisterListener(this);
            this.unregisterReceiver(this.medeBateria);
        }
        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {
            if (sensorEvent.values[0] > 20) {

                Toast.makeText(this, "Aplicação encerrada!", Toast.LENGTH_SHORT).show();
                finish();
            }
        }
        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {

        }
        public BroadcastReceiver medeBateria = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                int carga = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);
                if (carga < 50)
                    Toast.makeText(context, "Bateria com menos de 50% ", Toast.LENGTH_SHORT).show();
            }
        };

}