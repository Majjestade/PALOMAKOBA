package com.example.projetofinalandroid2;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class BancoDeEnderecos extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "Enderecos";
    private static final int DATABASE_VERSION = 1;
    private static final String CREATE_TABLE_ENDERECOS =
            "CREATE TABLE enderecos (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "CEP TEXT," +
                    "RUA TEXT," +
                    "BAIRRO TEXT," +
                    "CIDADE TEXT);";

    public BancoDeEnderecos(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_TABLE_ENDERECOS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS enderecos");
        onCreate(sqLiteDatabase);
    }

    public long inserir(ContentValues cv) {
        SQLiteDatabase db = this.getWritableDatabase();
        long id = db.insert("enderecos", null, cv);

        return id;
    }
    public List<ContentValues> listarTodos() {
        String sql = "SELECT * FROM enderecos ORDER BY id";
        String where[] = null;

        return listar(sql, where);
    }




    @SuppressLint("Range")
    private List<ContentValues> listar(String sql, String where[]) {
        List<ContentValues> lista = new ArrayList<>();
        SQLiteDatabase bd = this.getReadableDatabase();
        Cursor c = bd.rawQuery(sql, where);

        Log.i("val","tamanho "+c.moveToFirst());

        /*if (c.moveToFirst()) {
            do {
                ContentValues cv = new ContentValues();
                cv.put("id", c.getInt( c.getColumnIndex("id")) );
                cv.put("cep", c.getString( c.getColumnIndex("CEP")) );
                cv.put("rua", c.getString( c.getColumnIndex("RUA")) );
                cv.put("bairro", c.getString( c.getColumnIndex("BAIRRO")) );
                cv.put("cidade", c.getString( c.getColumnIndex("CIDADE")) );
                lista.add(cv);

                StringBuilder md = new StringBuilder();

                md.append(c.getColumnIndex("id")).append("\n")
                .append(c.getColumnIndex("CEP")).append("\n")
                .append(c.getColumnIndex("RUA")).append("\n")
                .append(c.getColumnIndex("BAIRRO")).append("\n")
                .append(c.getColumnIndex("CIDADE")).append("\n ================= \n");

                Log.i("val",""+c.getString( c.getColumnIndex("CIDADE")));

            }while (c.moveToNext());
        }//*/

        while (c.moveToNext())
            {
                ContentValues cv = new ContentValues();
                cv.put("id", c.getInt( c.getColumnIndex("id")) );
                cv.put("cep", c.getString( c.getColumnIndex("CEP")) );
                cv.put("rua", c.getString( c.getColumnIndex("RUA")) );
                cv.put("bairro", c.getString( c.getColumnIndex("BAIRRO")) );
                cv.put("cidade", c.getString( c.getColumnIndex("CIDADE")) );
                lista.add(cv);

            }

        return lista;
    }


    public void deletaEnder(int id) {
        String where = "id = " + id;
        SQLiteDatabase db = this.getReadableDatabase();
        db.delete("enderecos", where, null);
        db.close();
    }

}
