package com.example.projetofinalandroid2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.BatteryManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import com.example.projetofinalandroid2.model.AdapterEnder;
import java.util.ArrayList;
import java.util.List;

public class Tela_enderecos extends AppCompatActivity  {
  private Button btn_voltar;
  private RecyclerView recyclerView;
  private List<ContentValues> lista = new ArrayList<>();
  private BancoDeEnderecos bd;
  private AdapterEnder adapterEnder;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_enderecos);

        bd = new BancoDeEnderecos(Tela_enderecos.this);

        btn_voltar = findViewById(R.id.btn_voltar);
        recyclerView = findViewById(R.id.recycler);
        lista = bd.listarTodos();

        adapterEnder = new AdapterEnder(lista);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(adapterEnder);

            btn_voltar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    onBackPressed();
                }
            });

        }

}
