package com.example.projetofinalandroid2.model;



import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;
import com.example.projetofinalandroid2.BancoDeEnderecos;
import com.example.projetofinalandroid2.Mapa;
import com.example.projetofinalandroid2.R;
import java.util.ArrayList;
import java.util.List;

public class AdapterEnder extends RecyclerView.Adapter<AdapterEnder.MyViewHolder> {

    private List<ContentValues> lista = new ArrayList<>();

    public AdapterEnder(List<ContentValues> lista) {
        this.lista = lista;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
    View item = LayoutInflater.from(parent.getContext()).inflate(R.layout.componentes,parent,false);
        return new MyViewHolder(item);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        ContentValues cv = new ContentValues();
        cv = lista.get(position);



            holder.cep.setText(cv.getAsString("cep"));
            holder.rua.setText(cv.getAsString("rua"));
            holder.bairro.setText(cv.getAsString("bairro"));
            holder.cidade.setText(cv.getAsString("cidade"));
            holder.id.setText(cv.getAsString("id"));

    }

    @Override
    public int getItemCount() {
        return lista.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        private TextView id, rua, bairro, cep, cidade;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            cep = itemView.findViewById(R.id.cep);
            rua = itemView.findViewById(R.id.rua);
            cidade = itemView.findViewById(R.id.cidade);
            bairro = itemView.findViewById(R.id.bairro);
            id = itemView.findViewById(R.id.Id);

            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                    builder.setTitle("Confirme a exclusão");
                    builder.setMessage("Você realmente deseja excluir este endereço?");
                    builder.setCancelable(false);
                    builder.setNegativeButton("Não", null);
                    builder.setPositiveButton("Excluir", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            BancoDeEnderecos bd = new BancoDeEnderecos(itemView.getContext());

                            int recicla = Integer.parseInt(id.getText().toString());
                            bd.deletaEnder(recicla);

                            Toast.makeText(itemView.getContext(), "Endereço removido com sucesso!", Toast.LENGTH_SHORT).show();

                            lista.remove(getAdapterPosition());
                            notifyItemRemoved(getAdapterPosition());

                        }
                    });
                    builder.show();
                    return true;
                }
            });

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(itemView.getContext(), Mapa.class);
                    String ender = rua.getText().toString() + ", " + bairro.getText().toString()
                            + " - " + cidade.getText().toString() + "/" ;

                    intent.putExtra("endereco", ender);
                    intent.putExtra("tipo", "2");



                    itemView.getContext().startActivity(intent);


                }
            });
        }
    }
}
